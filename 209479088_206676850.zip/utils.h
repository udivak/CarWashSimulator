#ifndef UTILS_H
#define UTILS_H

float nextTime(float rateParameter);

#endif